package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/deleteCustomer")
public class deletecus extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "Abhi@123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        boolean proceed = Boolean.parseBoolean(request.getParameter("proceed"));

        Connection connection = null;
        PreparedStatement checkBalanceStmt = null;
        PreparedStatement deleteTransactionsStmt = null;
        PreparedStatement deleteUserStmt = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Check if account balance is zero
            String checkBalanceSQL = "SELECT balance FROM users WHERE id = ?";
            checkBalanceStmt = connection.prepareStatement(checkBalanceSQL);
            checkBalanceStmt.setInt(1, id);
            ResultSet rs = checkBalanceStmt.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance != 0.0 && !proceed) {
                    response.sendRedirect("deleteWarning.jsp?id=" + id);
                    return;
                }
            }

            connection.setAutoCommit(false); // Start transaction

            // First, delete transactions for the user
            String deleteTransactionsSQL = "DELETE FROM transactions WHERE Account_Number = ?";
            deleteTransactionsStmt = connection.prepareStatement(deleteTransactionsSQL);
            deleteTransactionsStmt.setInt(1, id);
            deleteTransactionsStmt.executeUpdate();

            // Now, delete the user
            String deleteUserSQL = "DELETE FROM users WHERE id = ?";
            deleteUserStmt = connection.prepareStatement(deleteUserSQL);
            deleteUserStmt.setInt(1, id);
            deleteUserStmt.executeUpdate();

            connection.commit(); // Commit transaction

            response.sendRedirect("viewCustomer.jsp");
        } catch (ClassNotFoundException | SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback(); // Rollback transaction in case of error
                } catch (SQLException ex) {
                    ex.printStackTrace(response.getWriter());
                }
            }
            e.printStackTrace(response.getWriter());
        } finally {
            try {
                if (checkBalanceStmt != null) checkBalanceStmt.close();
                if (deleteTransactionsStmt != null) deleteTransactionsStmt.close();
                if (deleteUserStmt != null) deleteUserStmt.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace(response.getWriter());
            }
        }
    }
}
