package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database URL, username, and password
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "Abhi@123";

    public LoginServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Read form fields
        String accountNumber = request.getParameter("account_number");
        String dob = request.getParameter("dob");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Prepare the SQL select statement
            String sql = "SELECT * FROM users WHERE account_number = ? AND dob = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, accountNumber);
            preparedStatement.setString(2, dob);

            // Execute the query
            resultSet = preparedStatement.executeQuery();

            // Check if a user exists with the given credentials
            if (resultSet.next()) {
                // Set session attributes and redirect to welcome.jsp
                HttpSession session = request.getSession();
                session.setAttribute("fullname", resultSet.getString("fullname"));
                session.setAttribute("account_number", resultSet.getString("account_number"));
                session.setAttribute("dob", resultSet.getString("dob"));
                session.setAttribute("address", resultSet.getString("address"));
                session.setAttribute("account_type", resultSet.getString("account_type"));
                session.setAttribute("id_proof", resultSet.getString("id_proof"));
                session.setAttribute("balance", resultSet.getDouble("balance"));
                response.sendRedirect("welcome.jsp");
            } else {
                // Invalid login, show error message
                request.setAttribute("error", "Invalid account number or date of birth.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=Database error");
        } finally {
            // Close resources
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
