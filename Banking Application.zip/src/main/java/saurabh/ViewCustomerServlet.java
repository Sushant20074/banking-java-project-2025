package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/viewCustomer")
public class ViewCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database URL, username, and password
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "Abhi@123";

    public ViewCustomerServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Prepare the SQL select statement
            String sql = "SELECT * FROM users";
            preparedStatement = connection.prepareStatement(sql);

            // Execute the query
            resultSet = preparedStatement.executeQuery();

            // HTML and CSS setup
            out.println("<html><head><title>View Customers</title>");
            out.println("<link rel='stylesheet' href='css/styles.css'></head><body>");
            out.println("<div class='navbar'>");
            out.println("<a href='adminDashboard.jsp'>Dashboard</a>");
            out.println("<a href='addCustomer.jsp'>Add Customer</a>");
            out.println("<a href='updateCustomer.jsp'>Update Customer</a>");
            out.println("<a href='viewCustomer'>View Customer</a>");
            out.println("<a href='manageLoan.jsp'>Loan</a>");
            out.println("<a href='logout.jsp'>Logout</a>");
            out.println("</div>");
            out.println("<div class='content'>");
            out.println("<h2>Customer List</h2>");
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Full Name</th><th>Phone</th><th>Address</th><th>Account Number</th><th>Balance</th><th>Account Type</th><th>Actions</th></tr>");

            // Iterate through the result set
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                out.println("<tr>");
                out.println("<td>" + id + "</td>");
                out.println("<td>" + resultSet.getString("fullname") + "</td>");
                out.println("<td>" + resultSet.getString("mobile_number") + "</td>");
                out.println("<td>" + resultSet.getString("address") + "</td>");
                out.println("<td>" + resultSet.getString("account_number") + "</td>");
                out.println("<td>" + resultSet.getString("balance") + "</td>");
                out.println("<td>" + resultSet.getString("account_type") + "</td>");
                out.println("<td>");
                out.println("<form action='updateCustomerServlet' method='GET' style='display:inline;'>");
                out.println("<input type='hidden' name='id' value='" + id + "'>");
                out.println("<button class='update-button' type='submit'>Update</button>");
                out.println("</form>");
                out.println("<form action='deleteCustomer' method='POST' style='display:inline;'>");
                out.println("<input type='hidden' name='id' value='" + id + "'>");
                out.println("<button class='delete-button' type='submit' onclick='return confirm(\"Are you sure you want to delete this customer?\");'>Delete</button>");
                out.println("</form>");
                out.println("</td>");
                out.println("</tr>");
            }
            out.println("</table>");
            out.println("</div></body></html>");
        } catch (ClassNotFoundException e) {
            e.printStackTrace(out); // Print the error to the response
        } catch (SQLException e) {
            e.printStackTrace(out); // Print the error to the response
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace(out); // Print the error to the response
            }
        }
    }
}
