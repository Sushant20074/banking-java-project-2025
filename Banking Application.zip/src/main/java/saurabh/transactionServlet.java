package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/Trans")
public class transactionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Abhi@123";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String transactionType = request.getParameter("transactionType");
        double amount = Double.parseDouble(request.getParameter("amount"));

        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("account_number");

        if (accountNumber != null) {
            try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
                if ("Delete".equals(transactionType)) {
                    // Delete account
                    String deleteSql = "DELETE FROM users WHERE account_number = ?";
                    try (PreparedStatement deleteStatement = connection.prepareStatement(deleteSql)) {
                        deleteStatement.setString(1, accountNumber);
                        deleteStatement.executeUpdate();

                        // Redirect to a confirmation page or handle appropriately
                        response.sendRedirect("accountDeleted.jsp");
                    }
                } else {
                    // Perform deposit or withdrawal transaction
                    String insertSql = "INSERT INTO transactions (Account_Number, date, transaction_type, amount, closingbalance) VALUES (?, NOW(), ?, ?, ?)";
                    try (PreparedStatement insertStatement = connection.prepareStatement(insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                        insertStatement.setString(1, accountNumber);
                        insertStatement.setString(2, transactionType);
                        insertStatement.setDouble(3, amount);
                        insertStatement.setDouble(4, 0); // Initial closing balance as placeholder
                        insertStatement.executeUpdate();

                        // Get the generated key (id) of the inserted transaction
                        ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                        int transactionId = -1;
                        if (generatedKeys.next()) {
                            transactionId = generatedKeys.getInt(1);
                        }

                        // Update balance based on transaction type
                        double newBalance = 0;
                        String getBalanceSql = "SELECT balance FROM users WHERE account_number = ?";
                        try (PreparedStatement getBalanceStatement = connection.prepareStatement(getBalanceSql)) {
                            getBalanceStatement.setString(1, accountNumber);
                            ResultSet resultSet = getBalanceStatement.executeQuery();
                            if (resultSet.next()) {
                                newBalance = resultSet.getDouble("balance");
                            }
                        }

                        if ("Deposit".equals(transactionType)) {
                            newBalance += amount;
                        } else if ("Withdrawal".equals(transactionType)) {
                            newBalance -= amount;
                        }

                        // Update the closing balance in the transactions table
                        String updateTransactionBalanceSql = "UPDATE transactions SET closingbalance = ? WHERE id = ?";
                        try (PreparedStatement updateTransactionBalanceStatement = connection.prepareStatement(updateTransactionBalanceSql)) {
                            updateTransactionBalanceStatement.setDouble(1, newBalance);
                            updateTransactionBalanceStatement.setInt(2, transactionId);
                            updateTransactionBalanceStatement.executeUpdate();
                        }

                        // Update the balance in the users table
                        String updateBalanceSql = "UPDATE users SET balance = ? WHERE account_number = ?";
                        try (PreparedStatement updateBalanceStatement = connection.prepareStatement(updateBalanceSql)) {
                            updateBalanceStatement.setDouble(1, newBalance);
                            updateBalanceStatement.setString(2, accountNumber);
                            updateBalanceStatement.executeUpdate();
                        }

                        // Redirect to a transaction success page or handle appropriately
                        response.sendRedirect("transactionSuccessful.jsp");
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("transactionFailed.jsp");
            }
        } else {
            response.getWriter().println("Account number not found in session. Please log in again.");
        }
    }
}
