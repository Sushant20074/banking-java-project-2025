package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database URL, username, and password
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "Abhi@123";

    public RegisterServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Read form fields
        String fullname = request.getParameter("fullname");
        String mobileNumber = request.getParameter("mobile_number");
        String address = request.getParameter("address");
        String accountType = request.getParameter("account_type");
        String dob = request.getParameter("dob");
        String idProof = request.getParameter("id_proof");

        // Generate account number and temporary password
        String accountNumber = generateAccountNumber();
        String temporaryPassword = generateTemporaryPassword();

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Prepare the SQL insert statement
            String sql = "INSERT INTO users (fullname, mobile_number, address, account_number, account_type, dob, id_proof, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, fullname);
            preparedStatement.setString(2, mobileNumber);
            preparedStatement.setString(3, address);
            preparedStatement.setString(4, accountNumber);
            preparedStatement.setString(5, accountType);
            preparedStatement.setString(6, dob);
            preparedStatement.setString(7, idProof);
            preparedStatement.setString(8, temporaryPassword);

            // Execute the insert
            int rowsAffected = preparedStatement.executeUpdate();

            // Write response message and show popup
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            if (rowsAffected > 0) {
                // Show a popup with account number and temporary password
                out.println("<script>");
                out.println("alert('Registration successful!\\nAccount Number: " + accountNumber + "\\nTemporary Password: " + temporaryPassword + "');");
                out.println("window.location.href='register.jsp';"); // Redirect to registration page or any other page
                out.println("</script>");
            } else {
                out.println("<p>Registration failed.</p>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to generate a random 12-digit account number
    private String generateAccountNumber() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    // Method to generate a random 8-character alphanumeric password
    private String generateTemporaryPassword() {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 8; i++) {
            int index = random.nextInt(characters.length());
            sb.append(characters.charAt(index));
        }
        return sb.toString();
    }
}
