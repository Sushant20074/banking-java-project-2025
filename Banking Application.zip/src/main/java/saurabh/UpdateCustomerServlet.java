package saurabh;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/updateCustomerServlet")
public class UpdateCustomerServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database URL, username, and password
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "Abhi@123";

    public UpdateCustomerServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Prepare the SQL select statement
            String sql = "SELECT * FROM users WHERE id = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, id);

            // Execute the query
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // HTML setup
                out.println("<html><head><title>Update Customer</title>");
                out.println("<style>");
                out.println("body { font-family: Arial, sans-serif; background-color: #f0f0f0; }");
                out.println(".navbar { background-color: #333; overflow: hidden; }");
                out.println(".navbar a { float: left; display: block; color: #f2f2f2; text-align: center; padding: 14px 16px; text-decoration: none; }");
                out.println(".navbar a:hover { background-color: #ddd; color: black; }");
                out.println(".content { padding: 20px; }");
                out.println("h2 { color: #333; }");
                out.println("form { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 5px; box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1); }");
                out.println("label { font-weight: bold; }");
                out.println("input[type=text] { width: 100%; padding: 8px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; }");
                out.println("input[type=submit] { background-color: #4CAF50; color: white; padding: 12px 20px; border: none; border-radius: 4px; cursor: pointer; float: right; }");
                out.println("</style></head><body>");
                out.println("<div class='navbar'>");
                out.println("<a href='adminDashboard.jsp'>Dashboard</a>");
                out.println("<a href='register.jsp'>Add Customer</a>");
                out.println("<a href='viewCustomer.jsp'>Update Customer</a>");
                out.println("<a href='viewCustomer.jsp'>View Customer</a>");
                out.println("<a href='manageLoan.jsp'>Loan</a>");
                out.println("<a href='adlogout.jsp'>Logout</a>");
                out.println("</div>");
                out.println("<div class='content'>");
                out.println("<h2>Update Customer Details</h2>");
                out.println("<form action='updateCustomerServlet' method='POST'>");
                out.println("<input type='hidden' name='id' value='" + id + "'>");
                out.println("<label for='fullname'>Full Name:</label>");
                out.println("<input type='text' id='fullname' name='fullname' value='" + resultSet.getString("fullname") + "'><br><br>");
                out.println("<label for='dob'>Date of Birth:</label>");
                out.println("<input type='text' id='dob' name='dob' value='" + resultSet.getString("dob") + "'><br><br>");
                out.println("<label for='accountType'>Account Type:</label>");
                out.println("<input type='text' id='accountType' name='accountType' value='" + resultSet.getString("account_type") + "'><br><br>");
                out.println("<label for='mobileNo'>Mobile Number:</label>");
                out.println("<input type='text' id='mobileNo' name='mobileNo' value='" + resultSet.getString("mobile_number") + "'><br><br>");
                out.println("<label for='address'>Address:</label>");
                out.println("<input type='text' id='address' name='address' value='" + resultSet.getString("address") + "'><br><br>");
                out.println("<label for='idProof'>ID Proof:</label>");
                out.println("<input type='text' id='idProof' name='idProof' value='" + resultSet.getString("id_proof") + "'><br><br>");
                out.println("<input type='submit' value='Update'>");
                out.println("</form>");
                out.println("</div></body></html>");
            } else {
                out.println("<p>Customer not found.</p>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(out); // Print the error to the response
        } finally {
            // Close resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace(out); // Print the error to the response
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get parameters from the request
        int id = Integer.parseInt(request.getParameter("id"));
        String fullname = request.getParameter("fullname");
        String dob = request.getParameter("dob");
        String accountType = request.getParameter("accountType");
        String mobileNo = request.getParameter("mobileNo");
        String address = request.getParameter("address");
        String idProof = request.getParameter("idProof");

        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish the connection
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);

            // Prepare the SQL update statement
            String sql = "UPDATE users SET fullname = ?, dob = ?, account_type = ?, mobile_number = ?, address = ?, id_proof = ? WHERE id = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, fullname);
            preparedStatement.setString(2, dob);
            preparedStatement.setString(3, accountType);
            preparedStatement.setString(4, mobileNo);
            preparedStatement.setString(5, address);
            preparedStatement.setString(6, idProof);
            preparedStatement.setInt(7, id);

            // Execute the update
            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                response.sendRedirect("viewCustomer.jsp");
            } else {
                response.setContentType("text/html");
                response.getWriter().println("<p>Failed to update customer details.</p>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
