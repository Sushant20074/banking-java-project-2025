package saurabh;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet("/LoadTransactions")
public class LoadTransactionsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:mysql://localhost:3308/saurabh";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "Abhi@123";

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String accountNumber = (String) request.getSession().getAttribute("account_number");

        if (accountNumber == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.println("Account number not found in session. Please log in again.");
            return;
        }

        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            String query = "SELECT date, transaction_type, amount, closingbalance FROM transactions WHERE Account_Number = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, accountNumber);
                ResultSet resultSet = statement.executeQuery();

                StringBuilder htmlResponse = new StringBuilder();
                while (resultSet.next()) {
                    String date = resultSet.getString("date");
                    String transactionType = resultSet.getString("transaction_type");
                    double amount = resultSet.getDouble("amount");
                    double closingBalance = resultSet.getDouble("closingbalance");

                    htmlResponse.append("<tr>")
                                .append("<td>").append(date).append("</td>")
                                .append("<td>").append(transactionType).append("</td>")
                                .append("<td>").append(amount).append("</td>")
                                .append("<td>").append(closingBalance).append("</td>")
                                .append("</tr>");
                }

                out.print(htmlResponse.toString());
            }
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("Error retrieving transactions: " + e.getMessage());
        }
    }
}
